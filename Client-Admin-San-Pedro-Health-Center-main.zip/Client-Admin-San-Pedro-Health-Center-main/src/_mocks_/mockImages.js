// ----------------------------------------------------------------------

export const mockImgCover = (index) => `https://minimal-kit-react.vercel.app/static/mock-images/avatars/avatar_9.jpg`;
export const mockImgProduct = (index) => `/static/mock-images/products/product_${index}.jpg`;
export const mockImgAvatar = (index) => `https://minimal-kit-react.vercel.app/static/mock-images/avatars/avatar_9.jpg`;
