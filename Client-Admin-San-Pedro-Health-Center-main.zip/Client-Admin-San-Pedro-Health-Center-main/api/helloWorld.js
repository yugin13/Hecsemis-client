export default (req, res) => {
    res.statusCode = 200;
    res.send({ message: "helloWorld" });
  };